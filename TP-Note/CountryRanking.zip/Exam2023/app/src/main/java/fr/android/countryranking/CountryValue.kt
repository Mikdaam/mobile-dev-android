package fr.android.countryranking

data class CountryValue (
    val code: String,
    val name: String,
    val value: Float
)